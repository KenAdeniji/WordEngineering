public class InsufficientFundsException : Exception
{
}