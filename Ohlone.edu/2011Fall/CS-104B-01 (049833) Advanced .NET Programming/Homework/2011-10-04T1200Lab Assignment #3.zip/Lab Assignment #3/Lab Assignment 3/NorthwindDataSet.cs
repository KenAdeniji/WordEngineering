﻿namespace Lab_Assignment_3 {
    
    
    public partial class NorthwindDataSet {
    }
}




