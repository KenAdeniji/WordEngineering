﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data.SqlClient;
using System.Data;

namespace LabAssignment3ClassLibrary
{
    public class CustomersOrders
    {
        public static DataTable FillCustomersX()
        {
            SqlConnection sqlConnection = new SqlConnection(ConnectionString);
            sqlConnection.Open();
            string queryString = "SELECT * FROM dbo.Customers ORDER BY CompanyName";
            SqlDataAdapter adapter = new SqlDataAdapter(queryString, sqlConnection);

            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            return dataTable;
        }

        public static DataTable FillCustomersX(string customerId)
        {
            SqlConnection sqlConnection = new SqlConnection(ConnectionString);
            sqlConnection.Open();
            string queryString = String.Format(CustomersQueryWhereCustomerID, customerId);
            SqlDataAdapter adapter = new SqlDataAdapter(queryString, sqlConnection);

            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            return dataTable;
        }

      

        public static DataTable FillOrdersX(string customerId)
        {
            SqlConnection sqlConnection = new SqlConnection(ConnectionString);
            sqlConnection.Open();
            string queryString = String.Format(OrdersQueryWhereCustomerID, customerId);
            SqlDataAdapter adapter = new SqlDataAdapter(queryString, sqlConnection);

            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            return dataTable;
        }

        public static DataSet FillCustomers(DataSet dataset)
        {
          SqlConnection sqlConnection = new SqlConnection(ConnectionString);
          sqlConnection.Open();
          string queryString = "SELECT CustomerID, CompanyName, ContactName, ContactTitle, Address, City, Region, PostalCode, Country, Phone, Fax FROM dbo.Customers";
          SqlDataAdapter adapter =
            new SqlDataAdapter(queryString, sqlConnection);

          
          adapter.Fill(dataset);
          return dataset;
        }

        public static DataSet FillOrders(DataSet dataset)
        {
          SqlConnection sqlConnection = new SqlConnection(ConnectionString);
          sqlConnection.Open();
          string queryString = "SELECT OrderID, CustomerID, EmployeeID, OrderDate, RequiredDate, ShippedDate, ShipVia, Freight, ShipName, ShipAddress, ShipCity, ShipRegion, ShipPostalCode, ShipCountry FROM dbo.Orders";
          SqlDataAdapter adapter =
            new SqlDataAdapter(queryString, sqlConnection);


          adapter.Fill(dataset);
          return dataset;
        }

      public static DataSet FillCustomers(string customerId)
        {
          SqlConnection sqlConnection = new SqlConnection(ConnectionString);
          sqlConnection.Open();
          string queryString = String.Format(CustomersQueryWhereCustomerID, customerId);
          SqlDataAdapter adapter = new SqlDataAdapter(queryString, sqlConnection);

          DataSet dataset = new DataSet("Customers");
          adapter.Fill(dataset);
          return dataset;
        }
        
      public static DataSet FillOrders(string customerId)
        {
          SqlConnection sqlConnection = new SqlConnection(ConnectionString);
          sqlConnection.Open();
          string queryString = String.Format(OrdersQueryWhereCustomerID, customerId);
          SqlDataAdapter adapter = new SqlDataAdapter(queryString, sqlConnection);

          DataSet dataset = new DataSet();
          adapter.Fill(dataset);
          return dataset;
        }

        //public const string ConnectionString = @"Data Source=(local); Initial Catalog=NorthWind; Integrated Security=True;"; 
        public const string ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\Northwind.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True";
        public const string CustomersQueryWhereCustomerID = "SELECT * FROM dbo.Customers WHERE CustomerID = '{0}' ORDER BY CompanyName";
        public const string OrdersQueryWhereCustomerID = "SELECT * FROM dbo.Orders WHERE customerID = '{0}' ORDER BY OrderID";
    }
}
