﻿namespace Lab_Assignment_3
{
    partial class DatabaseNorthwindTablesCustomersOrdersForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
          this.components = new System.ComponentModel.Container();
          System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
          System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
          System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
          System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
          System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
          System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
          this.customersDataGridView = new System.Windows.Forms.DataGridView();
          this.customerIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
          this.addressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
          this.cityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
          this.regionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
          this.postalCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
          this.countryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
          this.customersBindingSource = new System.Windows.Forms.BindingSource(this.components);
          this.northwindDataSet = new Lab_Assignment_3.NorthwindDataSet();
          this.customersComboBox = new System.Windows.Forms.ComboBox();
          this.customersTableAdapter = new Lab_Assignment_3.NorthwindDataSetTableAdapters.CustomersTableAdapter();
          this.tableAdapterManager = new Lab_Assignment_3.NorthwindDataSetTableAdapters.TableAdapterManager();
          this.ordersTableAdapter = new Lab_Assignment_3.NorthwindDataSetTableAdapters.OrdersTableAdapter();
          this.ordersDataGridView = new System.Windows.Forms.DataGridView();
          this.orderIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
          this.shipCityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
          this.shipRegionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
          this.orderDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
          this.requiredDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
          this.shippedDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
          this.ordersBindingSource = new System.Windows.Forms.BindingSource(this.components);
          ((System.ComponentModel.ISupportInitialize)(this.customersDataGridView)).BeginInit();
          ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).BeginInit();
          ((System.ComponentModel.ISupportInitialize)(this.northwindDataSet)).BeginInit();
          ((System.ComponentModel.ISupportInitialize)(this.ordersDataGridView)).BeginInit();
          ((System.ComponentModel.ISupportInitialize)(this.ordersBindingSource)).BeginInit();
          this.SuspendLayout();
          // 
          // customersDataGridView
          // 
          this.customersDataGridView.AutoGenerateColumns = false;
          dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
          dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
          dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
          dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
          dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
          dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
          dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
          this.customersDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
          this.customersDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
          this.customersDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.customerIDDataGridViewTextBoxColumn,
            this.addressDataGridViewTextBoxColumn,
            this.cityDataGridViewTextBoxColumn,
            this.regionDataGridViewTextBoxColumn,
            this.postalCodeDataGridViewTextBoxColumn,
            this.countryDataGridViewTextBoxColumn});
          this.customersDataGridView.DataSource = this.customersBindingSource;
          dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
          dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
          dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
          dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
          dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
          dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
          dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
          this.customersDataGridView.DefaultCellStyle = dataGridViewCellStyle8;
          this.customersDataGridView.Location = new System.Drawing.Point(13, 45);
          this.customersDataGridView.Name = "customersDataGridView";
          dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
          dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
          dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
          dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
          dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
          dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
          dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
          this.customersDataGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
          this.customersDataGridView.Size = new System.Drawing.Size(708, 150);
          this.customersDataGridView.TabIndex = 0;
          // 
          // customerIDDataGridViewTextBoxColumn
          // 
          this.customerIDDataGridViewTextBoxColumn.DataPropertyName = "CustomerID";
          this.customerIDDataGridViewTextBoxColumn.HeaderText = "CustomerID";
          this.customerIDDataGridViewTextBoxColumn.Name = "customerIDDataGridViewTextBoxColumn";
          // 
          // addressDataGridViewTextBoxColumn
          // 
          this.addressDataGridViewTextBoxColumn.DataPropertyName = "Address";
          this.addressDataGridViewTextBoxColumn.HeaderText = "Address";
          this.addressDataGridViewTextBoxColumn.Name = "addressDataGridViewTextBoxColumn";
          // 
          // cityDataGridViewTextBoxColumn
          // 
          this.cityDataGridViewTextBoxColumn.DataPropertyName = "City";
          this.cityDataGridViewTextBoxColumn.HeaderText = "City";
          this.cityDataGridViewTextBoxColumn.Name = "cityDataGridViewTextBoxColumn";
          // 
          // regionDataGridViewTextBoxColumn
          // 
          this.regionDataGridViewTextBoxColumn.DataPropertyName = "Region";
          this.regionDataGridViewTextBoxColumn.HeaderText = "Region";
          this.regionDataGridViewTextBoxColumn.Name = "regionDataGridViewTextBoxColumn";
          // 
          // postalCodeDataGridViewTextBoxColumn
          // 
          this.postalCodeDataGridViewTextBoxColumn.DataPropertyName = "PostalCode";
          this.postalCodeDataGridViewTextBoxColumn.HeaderText = "PostalCode";
          this.postalCodeDataGridViewTextBoxColumn.Name = "postalCodeDataGridViewTextBoxColumn";
          // 
          // countryDataGridViewTextBoxColumn
          // 
          this.countryDataGridViewTextBoxColumn.DataPropertyName = "Country";
          this.countryDataGridViewTextBoxColumn.HeaderText = "Country";
          this.countryDataGridViewTextBoxColumn.Name = "countryDataGridViewTextBoxColumn";
          // 
          // customersBindingSource
          // 
          this.customersBindingSource.DataMember = "Customers";
          this.customersBindingSource.DataSource = this.northwindDataSet;
          // 
          // northwindDataSet
          // 
          this.northwindDataSet.DataSetName = "NorthwindDataSet";
          this.northwindDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
          // 
          // customersComboBox
          // 
          this.customersComboBox.DataSource = this.customersBindingSource;
          this.customersComboBox.DisplayMember = "CompanyName";
          this.customersComboBox.FormattingEnabled = true;
          this.customersComboBox.Location = new System.Drawing.Point(13, 18);
          this.customersComboBox.Name = "customersComboBox";
          this.customersComboBox.Size = new System.Drawing.Size(282, 21);
          this.customersComboBox.TabIndex = 1;
          this.customersComboBox.ValueMember = "CustomerID";
          this.customersComboBox.SelectionChangeCommitted += new System.EventHandler(this.customersComboBox_SelectionChangeCommitted);
          // 
          // customersTableAdapter
          // 
          this.customersTableAdapter.ClearBeforeFill = true;
          // 
          // tableAdapterManager
          // 
          this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
          this.tableAdapterManager.CustomersTableAdapter = this.customersTableAdapter;
          this.tableAdapterManager.OrdersTableAdapter = this.ordersTableAdapter;
          this.tableAdapterManager.UpdateOrder = Lab_Assignment_3.NorthwindDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
          // 
          // ordersTableAdapter
          // 
          this.ordersTableAdapter.ClearBeforeFill = true;
          // 
          // ordersDataGridView
          // 
          this.ordersDataGridView.AutoGenerateColumns = false;
          dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
          dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
          dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
          dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
          dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
          dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
          dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
          this.ordersDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
          this.ordersDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
          this.ordersDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.orderIDDataGridViewTextBoxColumn,
            this.shipCityDataGridViewTextBoxColumn,
            this.shipRegionDataGridViewTextBoxColumn,
            this.orderDateDataGridViewTextBoxColumn,
            this.requiredDateDataGridViewTextBoxColumn,
            this.shippedDateDataGridViewTextBoxColumn});
          this.ordersDataGridView.DataBindings.Add(new System.Windows.Forms.Binding("Tag", this.ordersBindingSource, "OrderDate", true, System.Windows.Forms.DataSourceUpdateMode.OnValidation, null, "YYYY-MM-DDTHH:mm:ss"));
          this.ordersDataGridView.DataSource = this.ordersBindingSource;
          dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
          dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
          dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
          dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
          dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
          dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
          dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
          this.ordersDataGridView.DefaultCellStyle = dataGridViewCellStyle11;
          this.ordersDataGridView.Location = new System.Drawing.Point(13, 201);
          this.ordersDataGridView.Name = "ordersDataGridView";
          dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
          dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
          dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
          dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
          dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
          dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
          dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
          this.ordersDataGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
          this.ordersDataGridView.Size = new System.Drawing.Size(707, 150);
          this.ordersDataGridView.TabIndex = 2;
          // 
          // orderIDDataGridViewTextBoxColumn
          // 
          this.orderIDDataGridViewTextBoxColumn.DataPropertyName = "OrderID";
          this.orderIDDataGridViewTextBoxColumn.HeaderText = "OrderID";
          this.orderIDDataGridViewTextBoxColumn.Name = "orderIDDataGridViewTextBoxColumn";
          this.orderIDDataGridViewTextBoxColumn.ReadOnly = true;
          // 
          // shipCityDataGridViewTextBoxColumn
          // 
          this.shipCityDataGridViewTextBoxColumn.DataPropertyName = "ShipCity";
          this.shipCityDataGridViewTextBoxColumn.HeaderText = "ShipCity";
          this.shipCityDataGridViewTextBoxColumn.Name = "shipCityDataGridViewTextBoxColumn";
          // 
          // shipRegionDataGridViewTextBoxColumn
          // 
          this.shipRegionDataGridViewTextBoxColumn.DataPropertyName = "ShipRegion";
          this.shipRegionDataGridViewTextBoxColumn.HeaderText = "ShipRegion";
          this.shipRegionDataGridViewTextBoxColumn.Name = "shipRegionDataGridViewTextBoxColumn";
          // 
          // orderDateDataGridViewTextBoxColumn
          // 
          this.orderDateDataGridViewTextBoxColumn.DataPropertyName = "OrderDate";
          this.orderDateDataGridViewTextBoxColumn.HeaderText = "OrderDate";
          this.orderDateDataGridViewTextBoxColumn.Name = "orderDateDataGridViewTextBoxColumn";
          // 
          // requiredDateDataGridViewTextBoxColumn
          // 
          this.requiredDateDataGridViewTextBoxColumn.DataPropertyName = "RequiredDate";
          this.requiredDateDataGridViewTextBoxColumn.HeaderText = "RequiredDate";
          this.requiredDateDataGridViewTextBoxColumn.Name = "requiredDateDataGridViewTextBoxColumn";
          // 
          // shippedDateDataGridViewTextBoxColumn
          // 
          this.shippedDateDataGridViewTextBoxColumn.DataPropertyName = "ShippedDate";
          this.shippedDateDataGridViewTextBoxColumn.HeaderText = "ShippedDate";
          this.shippedDateDataGridViewTextBoxColumn.Name = "shippedDateDataGridViewTextBoxColumn";
          // 
          // ordersBindingSource
          // 
          this.ordersBindingSource.DataMember = "Orders";
          this.ordersBindingSource.DataSource = this.northwindDataSet;
          // 
          // DatabaseNorthwindTablesCustomersOrdersForm
          // 
          this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
          this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
          this.ClientSize = new System.Drawing.Size(732, 358);
          this.Controls.Add(this.ordersDataGridView);
          this.Controls.Add(this.customersComboBox);
          this.Controls.Add(this.customersDataGridView);
          this.Name = "DatabaseNorthwindTablesCustomersOrdersForm";
          this.Text = "DatabaseNorthwindTablesCustomersOrdersForm";
          this.Load += new System.EventHandler(this.DatabaseNorthwindTablesCustomersOrdersForm_Load);
          ((System.ComponentModel.ISupportInitialize)(this.customersDataGridView)).EndInit();
          ((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).EndInit();
          ((System.ComponentModel.ISupportInitialize)(this.northwindDataSet)).EndInit();
          ((System.ComponentModel.ISupportInitialize)(this.ordersDataGridView)).EndInit();
          ((System.ComponentModel.ISupportInitialize)(this.ordersBindingSource)).EndInit();
          this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView customersDataGridView;
        private System.Windows.Forms.ComboBox customersComboBox;
        private NorthwindDataSet northwindDataSet;
        private System.Windows.Forms.BindingSource customersBindingSource;
        private NorthwindDataSetTableAdapters.CustomersTableAdapter customersTableAdapter;
        private NorthwindDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private NorthwindDataSetTableAdapters.OrdersTableAdapter ordersTableAdapter;
        private System.Windows.Forms.DataGridView ordersDataGridView;
        private System.Windows.Forms.BindingSource ordersBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn regionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn postalCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn countryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn shipCityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn shipRegionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn requiredDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn shippedDateDataGridViewTextBoxColumn;
    }
}