﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using LabAssignment3ClassLibrary;

namespace Lab_Assignment_3
{
    public partial class DatabaseNorthwindTablesCustomersOrdersForm : Form
    {
        public DatabaseNorthwindTablesCustomersOrdersForm()
        {
            InitializeComponent();
        }

        private void DatabaseNorthwindTablesCustomersOrdersForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'northwindDataSet.Orders' table. You can move, or remove it, as needed.
            //CustomersOrders.FillOrders(this.northwindDataSet);
          this.customersTableAdapter.Fill(this.northwindDataSet.Customers);
            // TODO: This line of code loads data into the 'northwindDataSet.Customers' table. You can move, or remove it, as needed.
          //CustomersOrders.FillCustomers(this.northwindDataSet);
          this.ordersTableAdapter.Fill(this.northwindDataSet.Orders);

           //Set up customers binding source for the combo box.

          this.customersBindingSource = new BindingSource();
          this.customersBindingSource.DataSource = this.northwindDataSet;
          this.customersBindingSource.DataMember = "customers";
          this.customersBindingSource.Sort = "CompanyName";
           

          // Bind the form controls.
          customersComboBox.DataSource = this.customersBindingSource;
          customersComboBox.DisplayMember = "CompanyName";
          customersComboBox.ValueMember = "CustomerID";
          customersComboBox.DataBindings.Add("text", this.customersBindingSource, 
            "CompanyName", false, DataSourceUpdateMode.Never);
          customersComboBox.SelectedIndex = -1;

         
         // Set up customers binding source for the grid .
          this.customersBindingSource = new BindingSource();
         this.customersBindingSource.DataSource = this.northwindDataSet;
         this.customersBindingSource.DataMember = "customers";
         

          // Set up the orders binding source for the grid.
         this.ordersBindingSource = new BindingSource();
         this.ordersBindingSource.DataSource = this.northwindDataSet;
         this.ordersBindingSource.DataMember = "orders";
       
        }

        private void customersComboBox_SelectionChangeCommitted(object sender, EventArgs e)
        {
          // Retrieve the customer and order information for the grids.
          String CustomerIDString= customersComboBox.SelectedValue.ToString();
          this.customersBindingSource.Filter = "customerid = '" + CustomerIDString + "'";

          // Initialize the customers grid's binding.       
          customersDataGridView.DataSource = this.customersBindingSource;

          // Initialize the orders grid's binding.
          ordersDataGridView.DataSource = this.ordersBindingSource;
          this.ordersBindingSource.Filter = "customerid = '" + CustomerIDString + "'";
        }

       
    }
}