﻿/*!@license
* Infragistics.Web.ClientUI templating localization resources 14.1.20141.1020
*
* Copyright (c) 2011-2014 Infragistics Inc.
*
* http://www.infragistics.com/
*
*/

/*global jQuery */
(function ($) {
    $.ig = $.ig || {};

    if (!$.ig.Templating) {
	    $.ig.Templating = {};

	    $.extend($.ig.Templating, {
		    locale: {
			    undefinedArgument: 'Грешка при опит да се вземе стойността на следното свойство от източника на данни: '
		    }
	    });
    }
})(jQuery);