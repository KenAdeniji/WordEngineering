package org.persistence.tutorial;

import org.junit.runner.*;
import org.junit.runners.*;

/*
import junit.framework.Test;
import junit.framework.TestSuite;
*/

@RunWith(Suite.class)
@Suite.SuiteClasses(value={
	PersonTest.class,
	BookTest.class,
	MyLibraryTest.class
})

public class AllTests {

}

/*
public class AllTests {
	public static Test suite() {
		TestSuite suite = new TestSuite("Test for org.totalbeginner.tutorial");
		//$JUnit-BEGIN$
		suite.addTestSuite(BookTest.class);
		suite.addTestSuite(PersonTest.class);
		suite.addTestSuite(MyLibraryTest.class);
		//$JUnit-END$
		return suite;
	}
}
*/