import java.io.*;
import java.util.*;

public class AdviceGuy {
	public static final String[] myStringArray = new String[]
	{
		"Message 0.", 
		"Message 1.",
		"Message 2.",
		"Message 3.", 
		"Message 4.",
		"Message 5.",
		"Message 6.", 
		"Message 7.",
		"Message 8.",
		"Message 9.",
	};
	
	public static void main (String[] args)
	{
		Calendar now = Calendar.getInstance();
		int myStringArrayLength = myStringArray.length;
		char repeat = ' ';
		int seed = now.get(Calendar.SECOND);  
		Random generator = new Random(seed);
		do {
			int random = generator.nextInt(myStringArrayLength);
			System.out.println(myStringArray[random]);
			repeat = acceptSingleCharacter("Quit (Q) or Continue (C): ");
		} while (repeat == 'C');
	}
	
	public static String acceptLineInput(String messageLine)
	{
		String userInput = "";

		System.out.print(messageLine);
		try {
			BufferedReader consoleIn = new BufferedReader(new InputStreamReader(System.in));
			userInput = consoleIn.readLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userInput;
	}	

	public static char acceptSingleCharacter(String messageLine)
	{
		String userInput = "";
		char firstLetter = ' ';

		userInput = acceptLineInput(messageLine);
		userInput = userInput.toUpperCase();
		firstLetter = userInput.charAt(0);
		return firstLetter;
	}	
}
