package WordEngineering;

public class AreaOfATriangleHelper
{
	public static final String AreaOfATriangle = "Area of a Triangle: %f";
	public static final String UserName = "ohlone2";
	public static final String PassWord = "student2";
	
	public static char firstChar(String wholeInput)
	{
		wholeInput = wholeInput.toUpperCase();
		char firstEntry = wholeInput.charAt(0);
		return firstEntry;
	}
}
