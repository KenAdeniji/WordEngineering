/******************************************************************************* 
 * Copyright (c) 2005, 2007 Naci Dai, Lawrence Mandel, and Arthur Ryman. 
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution, and is available at 
 * http://www.eclipse.org/legal/epl-v10.html 
 * 
 * This sample developed for the book 
 *     Eclipse Web Tools Platform: Developing Java Web Applications
 * See http://eclipsewtp.org 
 *******************************************************************************/ 
package com.leagueplanet;

public class HockeyGame {
	
	private String league;
	private String scheduleName;
	private String date;
	private String time;
	private String arena;
	private String visitor;
	private String home;
	private int visitorGoals;
	private int homeGoals;
	
	public String getLeague() {return league;}
	public void setLeague(String league) {this.league = league;}

	public String getScheduleName() {return scheduleName;}
	public void setScheduleName(String scheduleName) {this.scheduleName = scheduleName;}

	public String getDate() {return date;}
	public void setDate(String date) {this.date = date;}

	public String getTime() {return time;}
	public void setTime(String time) {this.time = time;}

	public String getArena() {return arena;}
	public void setArena(String arena) {this.arena = arena;}

	public String getVisitor() {return visitor;}
	public void setVisitor(String visitor) {this.visitor = visitor;}

	public String getHome() {return home;}
	public void setHome(String home) {this.home = home;}

	public int getVisitorGoals() {return visitorGoals;}
	public void setVisitorGoals(int visitorGoals) {this.visitorGoals = visitorGoals;}

	public int getHomeGoals() {return homeGoals;}
	public void setHomeGoals(int homeGoals) {this.homeGoals = homeGoals;}

}
