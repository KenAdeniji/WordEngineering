package WordEngineering;

public class InterestHelper
{
	public static final String UserName = "ohlone3";
	public static final String PassWord = "student3";
	
	public static char firstChar(String wholeInput)
	{
		wholeInput = wholeInput.toUpperCase();
		char firstEntry = wholeInput.charAt(0);
		return firstEntry;
	}
}
