package com.ohlone.ejb3;

import java.io.Serializable;

public interface IMyBean extends Serializable {
	public String doSomething();
}
