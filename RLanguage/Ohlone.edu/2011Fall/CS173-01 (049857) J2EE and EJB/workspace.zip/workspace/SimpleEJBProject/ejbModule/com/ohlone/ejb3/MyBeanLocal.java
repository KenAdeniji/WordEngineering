package com.ohlone.ejb3;
import javax.ejb.Local;

@Local
public interface MyBeanLocal {

}
