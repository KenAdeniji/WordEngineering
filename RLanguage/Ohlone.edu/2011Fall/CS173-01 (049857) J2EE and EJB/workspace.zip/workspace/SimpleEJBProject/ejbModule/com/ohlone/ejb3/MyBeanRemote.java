package com.ohlone.ejb3;
import javax.ejb.Remote;

@Remote
public interface MyBeanRemote {

}
