package com.ohlone.ejb3;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class MyBean
 */
@Stateless (name="MyBean", mappedName="ejb/MyBeanJNDI") 
@LocalBean
public class MyBean extends Object implements MyBeanRemote, MyBeanLocal {
       
    /**
     * @see Object#Object()
     */
    public MyBean() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    public String doSomething() {
    	return "Hello World";
    }
}
