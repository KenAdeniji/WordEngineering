package com.ohlone.ejb3;

public class EJBClientTest {

}
