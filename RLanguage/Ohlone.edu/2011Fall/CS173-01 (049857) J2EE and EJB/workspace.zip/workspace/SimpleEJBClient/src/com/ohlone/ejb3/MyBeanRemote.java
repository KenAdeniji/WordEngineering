package com.ohlone.ejb3;

public interface MyBeanRemote extends MyBean{

}
