package com.ohlone.ejb3;

public interface MyBean {
    public String doSomething(); 
}
