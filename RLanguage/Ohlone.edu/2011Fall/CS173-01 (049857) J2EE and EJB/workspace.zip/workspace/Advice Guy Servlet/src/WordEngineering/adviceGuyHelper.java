package WordEngineering;

public class adviceGuyHelper
{
	public static final String[] myStringArray = new String[]
	{
		"Message 0.", 
		"Message 1.",
		"Message 2.",
		"Message 3.", 
		"Message 4.",
		"Message 5.",
		"Message 6.", 
		"Message 7.",
		"Message 8.",
		"Message 9.",
	};

	public static final String quitOrContinue = "Quit (Q) or Continue (C): ";
	
	public static char firstChar(String wholeInput)
	{
		wholeInput = wholeInput.toUpperCase();
		char firstEntry = wholeInput.charAt(0);
		return firstEntry;
	}
}
