package WordEngineering;

import java.io.*;
import java.io.IOException;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class index
 */
@WebServlet("/index")
public class index extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public index() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

	    out.println("<form action='quitOrContinue' method='post' id='index'>");
		Calendar now = Calendar.getInstance();
		int myStringArrayLength = adviceGuyHelper.myStringArray.length; 
		int seed = now.get(Calendar.SECOND);  
		Random generator = new Random(seed);
		int random = generator.nextInt(myStringArrayLength);
		out.println(adviceGuyHelper.myStringArray[random]);
		out.println("<br/>");
		out.println(adviceGuyHelper.quitOrContinue);
		out.println("<input type='text' name='quitOrContinue'>");
		out.println("</form>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
