import java.io.*;

public class DispThread extends Thread {
	private String msg;
	
	public void run()
	{
		for (int i = 0; i < 10; ++i)
		{
			System.out.println(msg);
		}
	}
	
	DispThread(String msg)
	{
		this.msg = msg;
	}
}
