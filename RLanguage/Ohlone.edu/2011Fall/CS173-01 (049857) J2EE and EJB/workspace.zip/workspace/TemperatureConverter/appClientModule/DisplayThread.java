import java.io.*;

public class DisplayThread implements Runnable{

	private String msg;

	@Override
	public void run() {
		for (int i = 0; i < 10; ++i)
		{
			System.out.println(msg);
		}
	}
		
	DisplayThread(String msg)
	{
		this.msg = msg;
	}
}
