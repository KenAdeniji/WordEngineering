
public class ThreadTest {
	public static void main(String[] args) {
		DispThread dt1 = new DispThread("Hello");
		DispThread dt2 = new DispThread("World");
		
		dt1.start();
		dt2.start();
	}
}
