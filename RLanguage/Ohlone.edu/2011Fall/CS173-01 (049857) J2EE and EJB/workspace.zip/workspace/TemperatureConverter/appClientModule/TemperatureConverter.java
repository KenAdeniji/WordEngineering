import java.io.*;

public class TemperatureConverter {

	public static final String Programmer = "Ken";
	public static final String Celsuis = "Celsuis";
	public static final String Fahrenheit = "Fahrenheit";
	
	public static void main (String[] args)
	{
		char repeat = ' ';
		System.out.printf("Welcome to %s's Java EE program\n", Programmer);
		System.out.println("C to F and F 2 C Temperature Converter");
		do
		{
			String fromScale = "";
			String toScale = "";

			char outputScale = acceptOneInput("Enter choice: F/f ( for output in Fahrenheit) or C/c ( for output in Celsius): ");

			if (outputScale == 'C')
			{
				fromScale = Fahrenheit;
				toScale = Celsuis;
			}
			else
			{
				fromScale = Celsuis;
				toScale = Fahrenheit;
			}
				
			String prompt = "Enter temperature in " + fromScale + ": ";
			String fromInput = acceptLineInput(prompt);
			double fromTemperature = Double.parseDouble(fromInput);
			double toTemperature = 0;
			
			if (outputScale == 'C')
			{
				toTemperature = (fromTemperature - 32) * 5.0 / 9.0;
			}
			else
			{
				toTemperature = (fromTemperature * 9.0 / 5.0) + 32;
			}
			
			System.out.printf("The temperature in %s is %f: ", toScale, toTemperature);
			System.out.println();
			repeat = acceptOneInput("Do you wish to continue: ");	
		}while (repeat == 'Y');
		System.out.printf("Thanks for using your %s's program\n", Programmer); 
	} // main method

	public static String acceptLineInput(String messageLine)
	{
		String userInput = "";

		System.out.print(messageLine);
		try {
			BufferedReader consoleIn = new BufferedReader(new InputStreamReader(System.in));
			userInput = consoleIn.readLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userInput;
	}	

	public static char acceptOneInput(String messageLine)
	{
		String userInput = "";
		char firstLetter = ' ';

		userInput = acceptLineInput(messageLine);
		userInput = userInput.toUpperCase();
		firstLetter = userInput.charAt(0);
		return firstLetter;
	}	
}
