
public class ThreadSimulate {
	public static void main(String[] args) {
		DisplayThread dt1 = new DisplayThread("Hello");
		DisplayThread dt2 = new DisplayThread("World");
		
		Thread thread1 = new Thread(dt1);
		Thread thread2 = new Thread(dt2);
		
		thread1.start();
		thread2.start();
	}
}
