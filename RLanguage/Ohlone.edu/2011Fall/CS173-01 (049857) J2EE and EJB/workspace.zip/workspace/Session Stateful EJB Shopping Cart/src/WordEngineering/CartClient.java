package WordEngineering;

import java.util.Collection;
import java.util.Iterator;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class CartClient {
    public static void main(String [] args) throws NamingException {
       
        try {
            final Context context = getInitialContext();
            Cart cart = (Cart)context.lookup("CartBean");
            
            System.out.println("Adding items to cart");
            
            cart.addItem("Pizza");
            cart.addItem("Pasta");
            cart.addItem("Noodles");
            cart.addItem("Bread");
            cart.addItem("Butter");
            
            
            System.out.println("Listing cart contents");
            Collection items = cart.getItems();
            for (Iterator i = items.iterator(); i.hasNext();) {
            String item = (String) i.next();
            System.out.println("  " + item);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private static Context getInitialContext() throws NamingException {
        return new InitialContext();
    }
}
