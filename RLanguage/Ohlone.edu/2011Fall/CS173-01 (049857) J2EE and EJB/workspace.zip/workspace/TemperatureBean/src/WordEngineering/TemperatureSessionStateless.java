package WordEngineering;

import javax.ejb.Remote;

@Remote
public interface TemperatureSessionStateless {

}
