package WordEngineering;

import javax.ejb.Stateless;
import WordEngineering.TemperatureSessionStateless;

public @Stateless class TemperatureSessionStatelessBean implements TemperatureSessionStateless {
	double ConvertFahrenheitToCelsuis(double fahrenheit) {
		double celsuis = (fahrenheit - 32) * 5.0 / 9.0;
		return celsuis;
	}
	
	double ConvertCelsuisToFahrenheit(double celsuis) {
		double fahrenheit = (celsuis * 9.0 / 5.0) + 32;
		return fahrenheit;
	}
}
