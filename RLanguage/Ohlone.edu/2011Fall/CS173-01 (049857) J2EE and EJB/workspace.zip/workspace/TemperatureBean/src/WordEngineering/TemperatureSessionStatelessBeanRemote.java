package WordEngineering;

import javax.ejb.Remote;

@Remote
public interface TemperatureSessionStatelessBeanRemote extends 
	TemperatureSessionStateless {

}
