package WordEngineering;

import javax.ejb.Local;

@Local
public interface TemperatureSessionStatelessBeanLocal 
	extends TemperatureSessionStateless 
{

}
