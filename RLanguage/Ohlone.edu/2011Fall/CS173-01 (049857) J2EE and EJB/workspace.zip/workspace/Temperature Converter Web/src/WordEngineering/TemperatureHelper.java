package WordEngineering;

public class TemperatureHelper
{
	public static final String Celsuis = "Celsuis";
	public static final String Fahrenheit = "Fahrenheit";
	
	public static final String EnterTemperatureIn = "Enter temperature in %s: ";
	public static final String DisplayTemperatureOut = "The temperature in %s is %f <br/>";
	public static final String Introduction = "C to F and F to C Temperature Converter <br/>";
	public static final String Programmer = "Ken";
	public static final String PromptContinue = "Do you wish to continue: ";
	public static final String ChooseScale = "Enter choice: F/f ( for output in Fahrenheit) or C/c ( for output in Celsius): ";
	public static final String ThankYou = "Thanks for using your %s's program."; 
	public static final String Welcome = "Welcome to %s's Java EE program <br/>";
	
	public static char firstChar(String wholeInput)
	{
		wholeInput = wholeInput.toUpperCase();
		char firstEntry = wholeInput.charAt(0);
		return firstEntry;
	}
}
