
public class HelloImpl {


public String sayHelloWorld()

{

return "Hello World Web Service ";

}

}
