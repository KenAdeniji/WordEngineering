package DefaultNamespace;

public class HelloImplProxy implements DefaultNamespace.HelloImpl {
  private String _endpoint = null;
  private DefaultNamespace.HelloImpl helloImpl = null;
  
  public HelloImplProxy() {
    _initHelloImplProxy();
  }
  
  public HelloImplProxy(String endpoint) {
    _endpoint = endpoint;
    _initHelloImplProxy();
  }
  
  private void _initHelloImplProxy() {
    try {
      helloImpl = (new DefaultNamespace.HelloImplServiceLocator()).getHelloImpl();
      if (helloImpl != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)helloImpl)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)helloImpl)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (helloImpl != null)
      ((javax.xml.rpc.Stub)helloImpl)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public DefaultNamespace.HelloImpl getHelloImpl() {
    if (helloImpl == null)
      _initHelloImplProxy();
    return helloImpl;
  }
  
  
}