package WordEngineering;

public class StudentSurveyHelper
{
	public static final String UserName = "ohlone1";
	public static final String PassWord = "student1";
	public static final String ThankYou = "Thank you Mr. %s for taking the survey.<br/>";
	
	public static char firstChar(String wholeInput)
	{
		wholeInput = wholeInput.toUpperCase();
		char firstEntry = wholeInput.charAt(0);
		return firstEntry;
	}
}
