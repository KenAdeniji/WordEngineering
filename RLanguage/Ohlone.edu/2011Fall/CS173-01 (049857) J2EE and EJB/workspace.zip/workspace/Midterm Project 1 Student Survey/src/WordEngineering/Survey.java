package WordEngineering;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Survey
 */
@WebServlet("/Survey")
public class Survey extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Survey() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		boolean loginSuccessful = false;
		
		if 
		(
			username.equals(StudentSurveyHelper.UserName) ||
			password.equals(StudentSurveyHelper.PassWord)
		)
		{
			loginSuccessful = true;
		}
		else
		{
			response.sendRedirect("index.jsp");
		}
	
	    out.println("<form action='thankyou.jsp' method='post' id='survey'>");
	    out.println("<label>Student Name:</label>");
	    out.println("<input type='text' name='studentName'><br/>");
	    out.println("<label>Student Id:</label>");
	    out.println("<input type='text' name='studentId'><br/>");
	    out.println("<input type='checkBox' name='courseASP'>");
	    out.println("<label>ASP</label><br/>");
	    out.println("<input type='checkBox' name='courseJSP'> JSP<br/>");
	    out.println("<input type='checkBox' name='courseJavaEE'> Java EE<br/>");
	    out.println("<input type='checkBox' name='courseXML'> XML<br/>");
	    out.println("<input type='checkBox' name='courseC++'> C++<br/>");
	    out.println("<input type='submit'>");
		out.println("</form>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
